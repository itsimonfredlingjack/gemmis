# Animation Recipes

Production-ready animation implementations for CLI/TUI applications.

## Glitch Overlay Effect

Full-screen glitch effect for transitions and errors:

```python
import random
from textual.widgets import Static
from rich.text import Text

class GlitchOverlay(Static):
    """Full-screen transparent overlay that creates digital glitches."""

    def on_mount(self) -> None:
        self.display = False
        self.set_interval(0.05, self.tick)
        self.glitch_active = False
        self.intensity = 0.1

    def trigger(self, duration: float = 0.5, intensity: float = 0.2):
        """Trigger a temporary glitch effect."""
        self.intensity = intensity
        self.glitch_active = True
        self.display = True
        self.set_timer(duration, self.stop_glitch)

    def stop_glitch(self):
        self.glitch_active = False
        self.display = False

    def tick(self):
        if self.glitch_active:
            self.refresh()

    def render(self) -> Text:
        if not self.glitch_active:
            return Text("")

        width = self.size.width
        height = self.size.height
        if width == 0 or height == 0:
            return Text("")

        chars = " ░▒▓█01_-"
        lines = []
        for _ in range(height):
            if random.random() < self.intensity:
                line = "".join(
                    random.choice(chars) if random.random() < 0.3 else " "
                    for _ in range(width)
                )
                style = "on #00ff00" if random.random() > 0.9 else "magenta"
                lines.append(Text(line, style=style))
            else:
                lines.append(Text(" " * width))

        return Text("\n").join(lines)
```

**CSS:**
```css
#glitch-overlay {
    display: none;
    width: 100%;
    height: 100%;
    layer: overlay;
    background: transparent;
}
```

**Usage:**
```python
# In your App class
def action_trigger_glitch(self) -> None:
    self.query_one(GlitchOverlay).trigger(0.3, 0.15)

# On error
self.query_one(GlitchOverlay).trigger(0.5, 0.3)
```

## Matrix Rain Effect

Falling code rain background:

```python
import random
from textual.widgets import Static
from rich.text import Text

class MatrixRain(Static):
    """Matrix-style falling characters."""

    def __init__(self):
        super().__init__(id="matrix-rain")
        self.columns = []
        self.chars = "アイウエオカキクケコサシスセソタチツテトナニヌネノ0123456789"

    def on_mount(self) -> None:
        self.display = False
        self._init_columns()
        self.set_interval(0.1, self.tick)

    def _init_columns(self):
        width = self.size.width or 80
        self.columns = [
            {
                "y": random.randint(-20, 0),
                "speed": random.randint(1, 3),
                "length": random.randint(5, 15)
            }
            for _ in range(width)
        ]

    def tick(self):
        if self.display:
            for col in self.columns:
                col["y"] += col["speed"]
                if col["y"] > (self.size.height or 24) + col["length"]:
                    col["y"] = random.randint(-20, -5)
                    col["speed"] = random.randint(1, 3)
            self.refresh()

    def render(self) -> Text:
        if not self.display:
            return Text("")

        width = self.size.width or 80
        height = self.size.height or 24

        # Build screen buffer
        screen = [[" " for _ in range(width)] for _ in range(height)]
        styles = [[None for _ in range(width)] for _ in range(height)]

        for x, col in enumerate(self.columns):
            if x >= width:
                continue
            for i in range(col["length"]):
                y = col["y"] - i
                if 0 <= y < height:
                    screen[y][x] = random.choice(self.chars)
                    # Brightest at head, dimmer trailing
                    if i == 0:
                        styles[y][x] = "bold #00ff00"
                    elif i < 3:
                        styles[y][x] = "#00cc00"
                    else:
                        styles[y][x] = "#006600"

        lines = []
        for y in range(height):
            line = Text()
            for x in range(width):
                char = screen[y][x]
                style = styles[y][x]
                if style:
                    line.append(char, style=style)
                else:
                    line.append(char)
            lines.append(line)

        return Text("\n").join(lines)
```

**Usage:**
```python
def action_toggle_matrix(self) -> None:
    matrix = self.query_one(MatrixRain)
    matrix.display = not matrix.display
```

## Particle System

Explosion effects for visual feedback:

```python
import random
from dataclasses import dataclass
from textual.widgets import Static
from rich.text import Text

@dataclass
class Particle:
    x: float
    y: float
    vx: float
    vy: float
    life: float
    char: str
    color: str

class ParticleSystem(Static):
    """Particle effects system for visual feedback."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.particles: list[Particle] = []

    def on_mount(self) -> None:
        self.set_interval(0.05, self.tick)

    def explode(self, x: int, y: int, count: int = 10, color: str = "yellow"):
        """Create explosion at position."""
        chars = "✦✧★☆◇◆●○"
        for _ in range(count):
            angle = random.uniform(0, 6.28)
            speed = random.uniform(1, 4)
            self.particles.append(Particle(
                x=float(x),
                y=float(y),
                vx=speed * random.uniform(-1, 1),
                vy=speed * random.uniform(-1, 1),
                life=random.uniform(0.5, 1.5),
                char=random.choice(chars),
                color=color
            ))

    def tick(self):
        # Update particles
        dt = 0.05
        for p in self.particles:
            p.x += p.vx
            p.y += p.vy
            p.vy += 0.5  # Gravity
            p.life -= dt

        # Remove dead particles
        self.particles = [p for p in self.particles if p.life > 0]
        self.refresh()

    def render(self) -> Text:
        if not self.particles:
            return Text("")

        width = self.size.width or 80
        height = self.size.height or 24

        screen = [[" " for _ in range(width)] for _ in range(height)]
        styles = [[None for _ in range(width)] for _ in range(height)]

        for p in self.particles:
            x, y = int(p.x), int(p.y)
            if 0 <= x < width and 0 <= y < height:
                screen[y][x] = p.char
                # Fade based on life
                if p.life > 0.7:
                    styles[y][x] = f"bold {p.color}"
                elif p.life > 0.3:
                    styles[y][x] = p.color
                else:
                    styles[y][x] = "dim"

        lines = []
        for y in range(height):
            line = Text()
            for x in range(width):
                char = screen[y][x]
                style = styles[y][x]
                if style:
                    line.append(char, style=style)
                else:
                    line.append(char)
            lines.append(line)

        return Text("\n").join(lines)
```

**Usage:**
```python
# On success
particles = self.query_one(ParticleSystem)
particles.explode(50, 20, count=15, color="green")

# On error
particles.explode(40, 10, count=20, color="red")
```

## Breathing Pulse Animation

Subtle "alive" animation for UI elements:

```python
async def breathing_pulse(self):
    """Make the UI 'breathe' by pulsing borders."""
    phase = 0
    while True:
        try:
            if self.is_generating:
                # Fast cycle during activity
                chat_display = self.query_one("#chat-display")
                classes = ["phase-1", "phase-2", "phase-3"]
                current = classes[phase % 3]
                prev = classes[(phase - 1) % 3]

                chat_display.remove_class(prev)
                chat_display.add_class(current)
                phase += 1
                await asyncio.sleep(0.2)
            else:
                # Slow pulse when idle
                sidebar = self.query_one(Sidebar)
                input_field = self.query_one("#message-input")

                sidebar.add_class("pulse")
                input_field.add_class("pulse")
                await asyncio.sleep(1.0)

                sidebar.remove_class("pulse")
                input_field.remove_class("pulse")
                await asyncio.sleep(1.0)
        except Exception:
            await asyncio.sleep(5)
```

**CSS:**
```css
/* Transition for smooth animation */
Sidebar { transition: border 500ms; }
#message-input { transition: border 500ms; }

/* Pulse states */
Sidebar.pulse { border-right: heavy $secondary; }
#message-input.pulse { border: heavy $accent; }

/* Phase states for activity */
.phase-1 { border: heavy $primary; }
.phase-2 { border: heavy $secondary; }
.phase-3 { border: heavy $accent; }
```

## Loading Spinner

Text-based loading indicator:

```python
from textual.widgets import Static
from textual.reactive import reactive

class LoadingSpinner(Static):
    """Animated loading spinner."""

    frame = reactive(0)
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    # Alternative: ["◐", "◓", "◑", "◒"]
    # Alternative: ["▁", "▂", "▃", "▄", "▅", "▆", "▇", "█", "▇", "▆", "▅", "▄", "▃", "▂"]

    def __init__(self, message: str = "Loading..."):
        super().__init__()
        self.message = message
        self._timer = None

    def on_mount(self) -> None:
        self._timer = self.set_interval(0.1, self.advance)

    def advance(self) -> None:
        self.frame = (self.frame + 1) % len(self.frames)

    def watch_frame(self, frame: int) -> None:
        self.update(f"[cyan]{self.frames[frame]}[/] {self.message}")

    def stop(self) -> None:
        if self._timer:
            self._timer.stop()
```

## Progress Bar with Blocks

```python
def render_animated_bar(
    percent: float,
    width: int = 30,
    color: str = "cyan",
    show_pulse: bool = True
) -> str:
    """Render an animated progress bar with block characters."""
    percent = min(max(percent, 0), 100)
    filled = int(width * (percent / 100))

    bar = "█" * filled

    # Fractional precision
    remainder = (width * (percent / 100)) - filled
    if len(bar) < width:
        if remainder > 0.75:
            bar += "▓"
        elif remainder > 0.5:
            bar += "▒"
        elif remainder > 0.25:
            bar += "░"

    # Fill remaining
    bar += "░" * (width - len(bar))
    bar = bar[:width]

    # Add pulse effect at the leading edge
    if show_pulse and filled > 0 and filled < width:
        bar_list = list(bar)
        bar_list[filled - 1] = "▓"  # Pulse character
        bar = "".join(bar_list)

    return f"[{color}]{bar}[/]"
```

## Typewriter Text Reveal

```python
import random
from textual.widgets import Static
from textual.reactive import reactive

class TypewriterText(Static):
    """Text that types itself out with optional glitch effect."""

    rendered = reactive("")

    def __init__(self, content: str, speed: float = 0.01, glitch: bool = True):
        super().__init__()
        self.full_content = content
        self.speed = speed
        self.glitch = glitch
        self.index = 0

    def on_mount(self) -> None:
        self.set_interval(self.speed, self.type_step)

    def type_step(self) -> None:
        if self.index >= len(self.full_content):
            return

        # Variable speed for natural feel
        step = random.randint(1, 3)
        self.index = min(self.index + step, len(self.full_content))

        visible = self.full_content[:self.index]

        if self.glitch and self.index < len(self.full_content):
            remaining = min(5, len(self.full_content) - self.index)
            glitch_chars = "".join(
                random.choice("ABCDEF0123456789") for _ in range(remaining)
            )
            self.rendered = visible + f"[dim]{glitch_chars}[/]"
        else:
            self.rendered = visible

    def watch_rendered(self, value: str) -> None:
        self.update(value)
```

## Performance Tips

1. **Use `set_interval` wisely:**
   - Fast animations: 0.01-0.05s (60-100fps)
   - Medium animations: 0.1s (10fps)
   - Slow updates: 1.0s (1fps)

2. **Consolidate updates:**
   ```python
   # Good: Single refresh
   self.update(new_content)

   # Bad: Multiple refreshes
   self.part1 = x
   self.part2 = y
   self.refresh()
   ```

3. **Use CSS transitions for simple animations:**
   ```css
   Widget { transition: border 500ms ease-in-out; }
   ```

4. **Layer overlays properly:**
   ```css
   Screen { layers: base effects overlay; }
   ```

5. **Clean up timers:**
   ```python
   def on_unmount(self) -> None:
       if self._timer:
           self._timer.stop()
   ```
