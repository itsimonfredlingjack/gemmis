# Reusable Widget Patterns

Production-ready Textual widget implementations for CLI/TUI applications.

## System Gauge Widget

A complete gauge with header, progress bar, and sparkline history:

```python
from collections import deque
from textual.app import ComposeResult
from textual.widgets import Static, Label, Sparkline, ProgressBar
from textual.containers import Vertical, Horizontal
from textual.reactive import reactive

class SystemGauge(Static):
    """A futuristic gauge for system metrics."""
    value = reactive(0.0)

    def __init__(self, label: str, color: str = "green"):
        super().__init__(classes="gauge-container")
        self.label_text = label
        self.bar_color = color
        self.history = deque([0.0] * 60, maxlen=60)

    def compose(self) -> ComposeResult:
        with Vertical():
            with Horizontal(classes="gauge-header"):
                yield Label(self.label_text, classes="gauge-label")
                yield Label("0%", id="gauge-value", classes="gauge-value")
            yield ProgressBar(total=100, show_eta=False, id="gauge-bar",
                            classes=f"gauge-{self.bar_color}")
            yield Sparkline(self.history, summary_function=max, id="gauge-spark")

    def update_val(self, val: float):
        self.value = val
        self.history.append(val)

        # Update text
        val_lbl = self.query_one("#gauge-value", Label)
        val_lbl.update(f"{val:.1f}%")

        # Update bar
        bar = self.query_one("#gauge-bar", ProgressBar)
        bar.progress = val

        # Update sparkline
        spark = self.query_one("#gauge-spark", Sparkline)
        spark.data = list(self.history)
```

**CSS for SystemGauge:**
```css
SystemGauge {
    width: 1fr;
    height: 100%;
    margin: 0 1;
    border: heavy $dim;
    background: $bg-dark;
    padding: 1;
}

SystemGauge:hover {
    border: heavy $primary;
}

.gauge-header {
    height: 1;
    align: center middle;
    margin-bottom: 1;
}

.gauge-label {
    color: $secondary;
    text-style: bold;
}

.gauge-value {
    color: $primary;
    text-style: bold;
}

.gauge-cyan > .bar--bar { color: $primary; background: $primary 30%; }
.gauge-magenta > .bar--bar { color: $accent; background: $accent 30%; }

Sparkline {
    width: 100%;
    height: 5;
    color: $success;
}
```

## Chat Bubble with Typewriter Effect

```python
import random
from textual.app import ComposeResult
from textual.widgets import Static, Markdown
from textual.containers import Vertical
from textual.reactive import reactive

class ChatBubble(Static):
    """A chat bubble with typewriter reveal effect."""

    rendered_content = reactive("")

    def __init__(self, role: str, content: str):
        super().__init__(classes=f"chat-bubble {role}")
        self.role = role
        self.full_content = content
        self.current_index = 0

        # Cyberpunk prefixes
        prefix = ""
        if role == "user":
            prefix = "▆▅▃ [USER_UPLINK] >> "
        elif role == "assistant":
            prefix = "█▓▒░ [AI_CORE] >> "
        elif role == "system":
            prefix = "[SYSTEM_LOG] :: "

        self.display_content = prefix + content

    def on_mount(self) -> None:
        if self.role in ["assistant", "system"]:
            self.set_interval(0.01, self.type_step)
        else:
            self.rendered_content = self.display_content

    def type_step(self) -> None:
        if self.current_index < len(self.display_content):
            step = random.randint(2, 5)
            self.current_index += step

            visible_part = self.display_content[:self.current_index]
            remaining_len = len(self.display_content) - self.current_index
            glitch_len = min(remaining_len, 5)

            glitch_part = ""
            if glitch_len > 0:
                chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
                glitch_part = "".join(random.choice(chars) for _ in range(glitch_len))
                glitch_part = f"[dim]{glitch_part}[/]"

            self.rendered_content = visible_part + glitch_part
            self.scroll_visible()
        else:
            self.rendered_content = self.display_content

    def compose(self) -> ComposeResult:
        yield Vertical(id="bubble-content")

    def watch_rendered_content(self, value: str) -> None:
        try:
            container = self.query_one("#bubble-content")
            for child in container.query("*"):
                child.remove()

            parts = value.split("```")
            for i, part in enumerate(parts):
                if i % 2 == 0:
                    if part.strip():
                        container.mount(Markdown(part))
                else:
                    lines = part.split("\n", 1)
                    lang = lines[0] if lines else ""
                    code = lines[1] if len(lines) > 1 else ""
                    container.mount(CodeBlock(code, lang))
        except Exception:
            pass
```

**CSS for ChatBubble:**
```css
ChatBubble {
    background: $bg-light;
    border: heavy $primary;
    padding: 1 2;
    margin: 1 0;
    width: 100%;
    max-width: 95%;
}

ChatBubble.user {
    border: heavy $secondary;
    margin-left: 10;
    text-align: right;
}

ChatBubble.assistant {
    border: heavy $primary;
    margin-right: 10;
}

ChatBubble.system {
    border: dashed $dim;
    color: $dim;
    text-align: center;
    background: $bg-dark;
}
```

## Code Block with Actions

```python
import pyperclip
from textual.app import ComposeResult
from textual.widgets import Static, Button, Markdown
from textual.containers import Vertical, Horizontal

class CodeBlock(Static):
    """Code block with copy/apply action buttons."""

    def __init__(self, code: str, language: str = ""):
        super().__init__(classes=language.strip())
        self.code = code
        self.language = language

    def compose(self) -> ComposeResult:
        with Vertical():
            if self.language.strip() != "ascii":
                with Horizontal(classes="code-toolbar"):
                    yield Button("Copy", id="copy")
                    yield Button("Apply", id="apply")
            yield Markdown(f"```{self.language}\n{self.code}\n```", id="code")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "copy":
            pyperclip.copy(self.code)
            self.notify("Code copied to clipboard.")
        elif event.button.id == "apply":
            # Custom apply logic here
            self.notify("Code applied!")
```

## Process Card

```python
from textual.widgets import Static
from textual.message import Message

def render_block_bar(percent: float, width: int = 20, theme_color: str = "green") -> str:
    """Renders a block-style progress bar."""
    percent = min(max(percent, 0), 100)
    filled_len = int(width * (percent / 100))
    bar = "█" * filled_len

    remainder = (width * (percent / 100)) - filled_len
    if len(bar) < width:
        if remainder > 0.5:
            bar += "▓"
        elif remainder > 0.25:
            bar += "▒"

    bar += "░" * (width - len(bar))
    return f"[{theme_color}]{bar[:width]}[/]"

class ProcessSelect(Message):
    """Event when process is clicked."""
    def __init__(self, pid: int, name: str) -> None:
        super().__init__()
        self.pid = pid
        self.name = name

class ProcessCard(Static):
    """A card displaying process information."""

    def __init__(self, proc: dict):
        super().__init__(classes="process-card")
        self.pid = proc['pid']
        self.proc_name = proc['name']
        self.update_info(proc)

    def update_info(self, proc: dict):
        self.cpu = proc['cpu_percent']
        self.mem = proc['memory_mb']

        if self.cpu > 50:
            self.add_class("surge")
        else:
            self.remove_class("surge")

        self.update(self._render_content())

    def _render_content(self) -> str:
        cpu_bar = render_block_bar(self.cpu, width=15, theme_color="cyan")
        return (
            f"[bold]{self.proc_name}[/] (PID {self.pid})\n"
            f"CPU: {cpu_bar} {self.cpu:.1f}%\n"
            f"MEM: [magenta]{self.mem:.1f} MB[/]"
        )

    def on_click(self) -> None:
        self.post_message(ProcessSelect(self.pid, self.proc_name))
```

## Confirmation Modal

```python
from textual.app import ComposeResult
from textual.widgets import Button, Label
from textual.containers import Vertical, Horizontal
from textual.screen import ModalScreen

class ConfirmModal(ModalScreen[bool]):
    """Generic confirmation modal."""

    def __init__(self, title: str, message: str):
        super().__init__()
        self.title_text = title
        self.message_text = message

    def compose(self) -> ComposeResult:
        with Vertical(id="confirm-dialog"):
            yield Label(self.title_text, classes="bold")
            yield Label(self.message_text)
            with Horizontal(classes="dialog-buttons"):
                yield Button("Confirm", variant="success", id="confirm")
                yield Button("Cancel", variant="error", id="cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        self.dismiss(event.button.id == "confirm")
```

## Animated Avatar Widget

```python
from textual.widgets import Static
from textual.reactive import reactive

# ASCII art states
AVATAR_STATES = {
    "idle": """
    ╭─────────╮
    │  ◉   ◉  │
    │    ▽    │
    │   ───   │
    ╰─────────╯
    """,
    "thinking": """
    ╭─────────╮
    │  ◎   ◎  │
    │    ▽    │
    │   ...   │
    ╰─────────╯
    """,
    "speaking": """
    ╭─────────╮
    │  ◉   ◉  │
    │    ▽    │
    │   ╭─╮   │
    ╰─────────╯
    """,
    "error": """
    ╭─────────╮
    │  ✖   ✖  │
    │    ▽    │
    │   ~~~   │
    ╰─────────╯
    """
}

class AvatarWidget(Static):
    """Animated avatar with state-based expressions."""

    state = reactive("idle")

    def __init__(self):
        super().__init__()

    def watch_state(self, new_state: str) -> None:
        art = AVATAR_STATES.get(new_state, AVATAR_STATES["idle"])
        self.update(art)

    def set_state(self, state: str) -> None:
        self.state = state
```

## Sidebar with Sections

```python
from textual.app import ComposeResult
from textual.widgets import Static
from textual.containers import Vertical

class Sidebar(Static):
    """Application sidebar with collapsible sections."""

    def __init__(self, state, client):
        super().__init__()
        self.app_state = state
        self.client = client

    def compose(self) -> ComposeResult:
        with Vertical():
            yield AvatarWidget()
            yield SystemStats()
            yield ModelSelector(self.client)
            yield SessionList()
            yield QuickActions()
```

**CSS for Sidebar:**
```css
Sidebar {
    width: 32;
    dock: left;
    background: $bg-dark;
    border-right: heavy $primary;
    scrollbar-size: 0 0;
    transition: border 500ms;
}

Sidebar.pulse {
    border-right: heavy $secondary;
}
```

## HUD Elements

```python
from textual.widgets import Static

# Top HUD
yield Static("╔═ APP_NAME v3.0 ════════════════════════╗",
             id="hud-top", classes="hud")

# Bottom HUD
yield Static("╚══ [STATUS: ONLINE] ══ [NET: SECURE] ══╝",
             id="hud-bottom", classes="hud")
```

**CSS for HUD:**
```css
.hud {
    dock: top;
    height: 1;
    width: 100%;
    background: $bg-dark;
    color: $dim;
    content-align: center middle;
    text-style: bold;
    layer: overlay;
}

#hud-bottom {
    dock: bottom;
}
```
