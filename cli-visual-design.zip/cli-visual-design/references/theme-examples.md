# Complete Theme Definitions

Production-ready theme implementations for CLI/TUI applications.

## Full Theme Dataclass

```python
from dataclasses import dataclass
from rich.text import Text

@dataclass
class Theme:
    """Theme definition with all color attributes."""

    name: str
    description: str

    # Core accent colors
    primary: str
    secondary: str
    accent: str

    # Semantic colors
    warning: str
    error: str
    success: str
    dim: str

    # Backgrounds
    bg_dark: str
    bg_light: str

    # Text
    text_primary: str
    text_secondary: str

    # Borders
    border_primary: str
    border_secondary: str

    # Syntax Highlighting (Pygments style name)
    code_theme: str = "monokai"

    # Optional gradient support
    gradient_start: str | None = None
    gradient_end: str | None = None

    def gradient_text(self, text: str) -> Text:
        """Create gradient-colored text using 24-bit TrueColor."""
        if not self.gradient_start or not self.gradient_end:
            return Text(text, style=self.primary)

        result = Text()
        start = self._hex_to_rgb(self.gradient_start)
        end = self._hex_to_rgb(self.gradient_end)

        length = len(text)
        if length <= 1:
            return Text(text, style=f"bold #{self.gradient_start.lstrip('#')}")

        for i, char in enumerate(text):
            t = i / (length - 1)
            r = int(start[0] + (end[0] - start[0]) * t)
            g = int(start[1] + (end[1] - start[1]) * t)
            b = int(start[2] + (end[2] - start[2]) * t)
            color = f"#{r:02x}{g:02x}{b:02x}"
            result.append(char, style=f"bold {color}")

        return result

    @staticmethod
    def _hex_to_rgb(hex_color: str) -> tuple[int, int, int]:
        """Convert hex color to RGB tuple."""
        hex_color = hex_color.lstrip("#")
        return tuple(int(hex_color[i : i + 2], 16) for i in (0, 2, 4))
```

## Nord Theme - Arctic Professional

```python
NORD = Theme(
    name="Nord",
    description="Arctic Professional - Frostbitten blue and snow white",
    primary="bold #88c0d0",      # Frost blue
    secondary="bold #81a1c1",    # Lighter frost
    accent="bold #eceff4",       # Snow white
    warning="bold #ebcb8b",      # Aurora yellow
    error="bold #bf616a",        # Aurora red
    success="bold #a3be8c",      # Aurora green
    dim="#4c566a",               # Polar night
    bg_dark="#2e3440",           # Polar night
    bg_light="#3b4252",          # Polar night lighter
    text_primary="#eceff4",      # Snow storm
    text_secondary="#d8dee9",    # Snow storm
    border_primary="#88c0d0",    # Frost
    border_secondary="#5e81ac",  # Frost darker
    code_theme="nord",
)
```

## Cyberpunk Theme - High-Voltage Neon

```python
CYBERPUNK = Theme(
    name="Cyberpunk",
    description="High-Voltage - Neon magenta and glowing yellow",
    primary="bold #ff00ff",      # Neon Magenta
    secondary="bold #00ffff",    # Cyan
    accent="bold #ffff00",       # Glowing Yellow
    warning="bold #ffff00",      # Yellow
    error="bold #ff0044",        # Hot Red
    success="bold #00ff00",      # Neon Green
    dim="#666666",               # Dark grey
    bg_dark="#0a0a0a",           # Near black
    bg_light="#1a1a2e",          # Dark purple
    text_primary="#ffffff",      # White
    text_secondary="#ff99ff",    # Light magenta
    border_primary="#ff00ff",    # Magenta
    border_secondary="#00ffff",  # Cyan
    code_theme="fruity",
)
```

## Synthwave Theme - Retro Future

```python
SYNTHWAVE = Theme(
    name="Synthwave",
    description="Retro Future - Purple to cyan gradients",
    primary="bold #f97ff5",      # Hot pink
    secondary="bold #72f1f5",    # Cyan
    accent="bold #fede5d",       # Retro yellow
    warning="bold #ff9e64",      # Orange
    error="bold #ff5555",        # Red
    success="bold #69ff94",      # Mint green
    dim="#848bbd",               # Muted purple
    bg_dark="#262335",           # Deep purple
    bg_light="#34294f",          # Purple
    text_primary="#ffffff",      # White
    text_secondary="#e8d4f8",    # Light purple
    border_primary="#f97ff5",    # Pink
    border_secondary="#72f1f5",  # Cyan
    code_theme="material",
    gradient_start="#f97ff5",    # Pink
    gradient_end="#72f1f5",      # Cyan
)
```

## Dracula Theme - Developer Classic

```python
DRACULA = Theme(
    name="Dracula",
    description="Industry Standard - The classic dark theme",
    primary="bold #bd93f9",      # Purple
    secondary="bold #8be9fd",    # Cyan
    accent="bold #f8f8f2",       # Foreground
    warning="bold #ffb86c",      # Orange
    error="bold #ff5555",        # Red
    success="bold #50fa7b",      # Green
    dim="#6272a4",               # Comment
    bg_dark="#282a36",           # Background
    bg_light="#44475a",          # Current line
    text_primary="#f8f8f2",      # Foreground
    text_secondary="#6272a4",    # Comment
    border_primary="#bd93f9",    # Purple
    border_secondary="#6272a4",  # Comment
    code_theme="dracula",
)
```

## Obsidian Theme - Minimalist Void

```python
OBSIDIAN = Theme(
    name="Obsidian",
    description="Minimalist Void - Deep black with gold accents",
    primary="bold #d4af37",      # Gold
    secondary="bold #808080",    # Grey
    accent="bold #c0c0c0",       # Silver
    warning="bold #d4af37",      # Gold
    error="bold #8b0000",        # Dark red
    success="bold #228b22",      # Forest green
    dim="#404040",               # Dark grey
    bg_dark="#0a0a0a",           # Near black
    bg_light="#141414",          # Slightly lighter
    text_primary="#c0c0c0",      # Silver
    text_secondary="#808080",    # Grey
    border_primary="#d4af37",    # Gold
    border_secondary="#404040",  # Dark grey
    code_theme="monokai",
)
```

## Theme Management System

```python
# Theme registry
THEMES = {
    "nord": NORD,
    "cyberpunk": CYBERPUNK,
    "synthwave": SYNTHWAVE,
    "dracula": DRACULA,
    "obsidian": OBSIDIAN,
}

# Current active theme
_current_theme: Theme = SYNTHWAVE

def set_theme(name: str) -> Theme:
    """Set the current theme by name."""
    global _current_theme
    name = name.lower()
    if name not in THEMES:
        available = ", ".join(THEMES.keys())
        raise ValueError(f"Unknown theme '{name}'. Available: {available}")
    _current_theme = THEMES[name]
    return _current_theme

def get_current_theme() -> Theme:
    """Get the currently active theme."""
    return _current_theme

def list_themes() -> list[str]:
    """Get list of available theme names."""
    return list(THEMES.keys())
```

## Dynamic CSS Variable Generation

```python
def get_css() -> str:
    """Generate CSS with theme variables."""
    theme = get_current_theme()

    def clean_color(c):
        return c.replace("bold ", "")

    variables = f"""
    $primary: {clean_color(theme.primary)};
    $secondary: {clean_color(theme.secondary)};
    $accent: {clean_color(theme.accent)};
    $warning: {clean_color(theme.warning)};
    $error: {clean_color(theme.error)};
    $success: {clean_color(theme.success)};
    $dim: {clean_color(theme.dim)};
    $bg-dark: {clean_color(theme.bg_dark)};
    $bg-light: {clean_color(theme.bg_light)};
    $text-primary: {clean_color(theme.text_primary)};
    $text-secondary: {clean_color(theme.text_secondary)};
    """

    return variables + STATIC_CSS
```

## Creating Custom Themes

To create a new theme:

1. Start with a base palette (3-5 colors)
2. Derive semantic colors from the palette
3. Test contrast ratios for accessibility
4. Verify in both light and dark terminals

```python
MY_CUSTOM_THEME = Theme(
    name="Custom",
    description="Your custom theme description",
    # Start with primary, secondary, accent
    primary="bold #your_primary",
    secondary="bold #your_secondary",
    accent="bold #your_accent",
    # Add semantic colors
    warning="bold #warning_color",
    error="bold #error_color",
    success="bold #success_color",
    dim="#muted_color",
    # Backgrounds (dark pair)
    bg_dark="#darkest_bg",
    bg_light="#elevated_bg",
    # Text colors
    text_primary="#main_text",
    text_secondary="#secondary_text",
    # Borders
    border_primary="#primary_border",
    border_secondary="#secondary_border",
    code_theme="monokai",  # Pygments theme
)
```
