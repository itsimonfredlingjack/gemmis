---
name: cli-visual-design
description: |
  This skill provides best practices for creating visually stunning, interactive CLI and TUI applications.
  It should be used when building terminal interfaces with Rich, Textual, or similar frameworks.
  Triggers include: "design a CLI", "TUI styling", "terminal UI", "make it beautiful", "visual effects",
  "theme system", "interactive terminal", "dashboard design", "CLI UX", or when creating any terminal-based
  application that needs professional visual design. Inspired by Gemini 3.0 Pro's generative UI principles
  and proven patterns from production TUI applications.
---

# CLI Visual Design Best Practices

This skill transforms terminal applications from plain text interfaces into visually compelling,
interactive experiences. Apply Gemini 3.0 Pro's generative UI philosophy to the terminal:
context-aware, richly styled, and deeply interactive.

## Core Design Philosophy

### The Generative UI Mindset

Terminal interfaces deserve the same design attention as graphical UIs. Apply these principles:

1. **Context-Responsive Design** - Adapt visuals to the task (debugging needs different UI than dashboards)
2. **Progressive Enhancement** - Start functional, layer visual polish
3. **Consistent Theming** - Never hardcode colors; use theme systems
4. **Motion with Purpose** - Animations communicate state, not just decoration

### The Three Pillars

```
┌─────────────────────────────────────────────────────────────┐
│  STRUCTURE          STYLE              BEHAVIOR             │
│  ───────────        ─────              ────────             │
│  Layout grids       Color palettes     Animations           │
│  Widget hierarchy   Typography         Transitions          │
│  Responsive sizing  Borders/Boxes      State feedback       │
│  Spacing rhythm     Semantic colors    User interactions    │
└─────────────────────────────────────────────────────────────┘
```

## Theme Architecture

### Theme Dataclass Pattern

Define themes as structured dataclasses with semantic color roles:

```python
@dataclass
class Theme:
    name: str
    description: str

    # Core accent colors (3 minimum)
    primary: str      # Main brand/action color
    secondary: str    # Supporting accent
    accent: str       # Highlights and emphasis

    # Semantic colors (required)
    warning: str      # Caution states
    error: str        # Error states
    success: str      # Success states
    dim: str          # Muted/disabled content

    # Backgrounds (light/dark pair)
    bg_dark: str      # Primary background
    bg_light: str     # Elevated surfaces

    # Text hierarchy
    text_primary: str    # Main content
    text_secondary: str  # Supporting text

    # Borders
    border_primary: str
    border_secondary: str

    # Optional: Gradients for premium effects
    gradient_start: str | None = None
    gradient_end: str | None = None
```

### Five Essential Themes

Provide at least 3-5 themes covering different aesthetics:

| Theme | Vibe | Primary | Background |
|-------|------|---------|------------|
| Nord | Arctic Professional | `#88c0d0` | `#2e3440` |
| Cyberpunk | Neon Intensity | `#ff00ff` | `#0a0a0a` |
| Synthwave | Retro Future | `#f97ff5` | `#262335` |
| Dracula | Developer Classic | `#bd93f9` | `#282a36` |
| Obsidian | Minimalist Void | `#d4af37` | `#0a0a0a` |

### Dynamic CSS Generation

Generate CSS from theme variables at runtime:

```python
def get_css() -> str:
    theme = get_current_theme()

    variables = f"""
    $primary: {theme.primary};
    $secondary: {theme.secondary};
    $bg-dark: {theme.bg_dark};
    /* ... more variables */
    """

    return variables + STATIC_CSS + COMPONENT_CSS
```

## Layout Patterns

### The Dashboard Grid

For data-heavy interfaces, use grid layouts:

```
┌──────────────────────────────────────────────────────────┐
│ ╔═══ HEADER / HUD ═════════════════════════════════════╗ │
├──────────┬───────────────────────────────────────────────┤
│ SIDEBAR  │  ┌─────────┐ ┌─────────┐ ┌─────────┐        │
│ (Fixed)  │  │ GAUGE 1 │ │ GAUGE 2 │ │ GAUGE 3 │        │
│          │  └─────────┘ └─────────┘ └─────────┘        │
│ - Avatar │  ┌──────────────────────────────────┐        │
│ - Stats  │  │                                  │        │
│ - Nav    │  │      MAIN CONTENT AREA           │        │
│ - Quick  │  │      (Scrollable)                │        │
│   Actions│  │                                  │        │
│          │  └──────────────────────────────────┘        │
├──────────┴───────────────────────────────────────────────┤
│ ╚═══ STATUS BAR / FOOTER ══════════════════════════════╝ │
└──────────────────────────────────────────────────────────┘
```

### Sidebar Pattern

Fixed-width sidebars (28-32 chars) with vertical sections:

```python
Sidebar {
    width: 32;
    dock: left;
    border-right: heavy $primary;
}
```

### Chat Interface Pattern

For conversational UIs, use differentiated bubbles:

```
┌─────────────────────────────────────────┐
│ ▆▅▃ [USER] >> Message from user         │  ← Right-aligned, secondary border
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│ █▓▒░ [AI] >> Response from assistant    │  ← Left-aligned, primary border
└─────────────────────────────────────────┘
```

## Visual Effects

### Progress Indicators

Use block characters for rich progress bars:

```python
def render_block_bar(percent: float, width: int = 20) -> str:
    filled = int(width * (percent / 100))
    bar = "█" * filled

    # Fractional blocks for precision
    remainder = (width * (percent / 100)) - filled
    if remainder > 0.5:
        bar += "▓"
    elif remainder > 0.25:
        bar += "▒"

    bar += "░" * (width - len(bar))
    return f"[{theme.primary}]{bar}[/]"
```

**Block Characters Reference:**
```
█ Full block     (100%)
▓ Dark shade     (75%)
▒ Medium shade   (50%)
░ Light shade    (25%)
▄ Lower half
▀ Upper half
```

### Typewriter Effect

For dramatic text reveals:

```python
class TypewriterWidget(Static):
    rendered_content = reactive("")

    def on_mount(self):
        self.set_interval(0.01, self.type_step)

    def type_step(self):
        if self.current_index < len(self.content):
            step = random.randint(2, 5)  # Variable speed
            self.current_index += step

            # "Decoding" effect with glitch chars ahead
            visible = self.content[:self.current_index]
            glitch = "".join(random.choice("ABCDEF0123456789")
                           for _ in range(min(5, remaining)))

            self.rendered_content = visible + f"[dim]{glitch}[/]"
```

### Glitch Overlay

For state transitions and errors:

```python
class GlitchOverlay(Static):
    def trigger(self, duration: float = 0.5, intensity: float = 0.2):
        self.display = True
        self.set_timer(duration, self.stop)

    def render(self) -> Text:
        chars = " ░▒▓█01_-"
        lines = []
        for _ in range(self.height):
            if random.random() < self.intensity:
                line = "".join(random.choice(chars) for _ in range(self.width))
                lines.append(Text(line, style="magenta"))
        return Text("\n").join(lines)
```

### Breathing/Pulse Animation

Make UIs feel alive with subtle animations:

```python
async def breathing_pulse(self):
    while True:
        sidebar.add_class("pulse")
        await asyncio.sleep(1.0)
        sidebar.remove_class("pulse")
        await asyncio.sleep(1.0)
```

```css
Sidebar { transition: border 500ms; }
Sidebar.pulse { border-right: heavy $secondary; }
```

### Sparklines for Data

Compact data visualization:

```python
from textual.widgets import Sparkline

# Store history
self.history = deque([0.0] * 60, maxlen=60)

# Update
self.history.append(new_value)
sparkline.data = list(self.history)
```

## Component Design Patterns

### System Gauge Widget

```
┌─────────────────────────────────────┐
│  CPU CORE                    78.5%  │
│  ████████████████░░░░░░░░░░░░░░░░  │
│  ▁▂▃▄▅▆▇█▇▆▅▄▃▂▁▂▃▄▅▆▇█▇▆▅▄▃     │  ← Sparkline history
└─────────────────────────────────────┘
```

### Process Card

```
┌─────────────────────────────────────┐
│ firefox (PID 12345)                 │
│ CPU: ██████████░░░░░ 45.2%          │
│ MEM: 256.8 MB                       │
└─────────────────────────────────────┘
```

### Code Block with Actions

```
┌─ python ───────────────── [Copy] [Apply] ─┐
│ def hello():                               │
│     print("Hello, World!")                 │
└────────────────────────────────────────────┘
```

## Animation Best Practices

From Textual's framework learnings:

1. **Overwrite, Don't Clear** - Replace content entirely; never clear then redraw
2. **Consolidate Output** - Single writes to stdout prevent flickering
3. **Target 60fps** - Higher rates give diminishing returns
4. **Use CSS Transitions** - Leverage built-in animation support
5. **Interval Timing** - `set_interval(0.01)` for smooth effects, `set_interval(1.0)` for data refresh

## Border Styles Reference

```
┌──────┐  ╔══════╗  ┏━━━━━━┓  ╭──────╮
│ thin │  ║ double║  ┃ heavy┃  │ round│
└──────┘  ╚══════╝  ┗━━━━━━┛  ╰──────╯

Border types: ascii, blank, dashed, double, heavy,
              hidden, hkey, inner, none, outer,
              panel, round, solid, tall, thick, vkey, wide
```

## Color Psychology for CLI

| Context | Color Choice | Hex Example |
|---------|-------------|-------------|
| Primary Action | Cyan/Blue | `#00ffff` |
| Success/Complete | Green | `#00ff00` |
| Warning/Caution | Yellow/Orange | `#ffb86c` |
| Error/Critical | Red | `#ff5555` |
| Muted/Disabled | Gray | `#666666` |
| Premium/Accent | Gold/Purple | `#d4af37` |

## Layers and Z-Index

For overlay effects, use Textual's layer system:

```css
Screen {
    layers: base matrix overlay;
}

#matrix-rain { layer: matrix; }
#glitch-overlay { layer: overlay; }
```

## References

For detailed implementation patterns, see:
- `references/theme-examples.md` - Complete theme definitions
- `references/widget-patterns.md` - Reusable widget code
- `references/animation-recipes.md` - Effect implementations

## Quick Start Checklist

When designing a CLI/TUI:

- [ ] Define a Theme dataclass with semantic colors
- [ ] Create 3+ theme variations
- [ ] Generate CSS from theme variables dynamically
- [ ] Use grid layouts for dashboards
- [ ] Add subtle animations (breathing, transitions)
- [ ] Include progress indicators with block characters
- [ ] Layer overlays for effects (glitch, matrix)
- [ ] Provide visual feedback for all state changes
- [ ] Test with different terminal sizes
- [ ] Support both dark and light terminals
